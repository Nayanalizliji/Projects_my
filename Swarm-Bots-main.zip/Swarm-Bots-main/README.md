In this project i build a swarm-based bot system using ESP32, exploring multi-node communication and coordination 
